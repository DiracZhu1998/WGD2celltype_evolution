suppressMessages(suppressWarnings(library(Seurat)))
suppressMessages(suppressWarnings(library(future)))
suppressMessages(suppressWarnings(library(dplyr)))
### Get the parameters
parser = argparse::ArgumentParser(description="Find markers with Seurat")
parser$add_argument('-I','--input', help='input Rdata')
parser$add_argument('-L','--label', help='input Seurat Idents label within metadata')
parser$add_argument('-O','--out', help='input output filename prefix')
args = parser$parse_args()

set.seed(42)

obj <- readRDS(args$input)
Idents(obj) <- args$label
plan("multisession", workers = 8)
Markers2 <- FindAllMarkers(obj, test.use = "wilcox", only.pos = T)
Markers2 <- Markers2 %>% filter(avg_log2FC > 0.58 & p_val_adj < 0.01 & pct.1 > 0.2)

write.table(x = Markers2, file = paste0(args$out, '.wilcox.FDR001.txt'), sep = "\t", quote = F, row.names = F, col.names = T)

