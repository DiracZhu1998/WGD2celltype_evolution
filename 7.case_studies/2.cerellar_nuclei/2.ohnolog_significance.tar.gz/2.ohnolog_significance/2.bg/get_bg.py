import sys, re

f=sys.argv[1]

for line in open(f):
    line = line.strip().split('\t')
    if line[-1] == 'protein_coding':
        print(line[0])

