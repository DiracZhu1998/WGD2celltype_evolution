
parser = argparse::ArgumentParser(description="Test paralog importance on cell marker genes")
parser$add_argument('-I','--input', help='input results folder')
parser$add_argument('-L','--label', help='input labelling')
args = parser$parse_args()

label <- args$label
input <- args$input


get_topN_RSS <- function(data, topN){
    apply(data, MARGIN = 2, FUN = function(x){ rownames(rss)[order(x, decreasing = T)][1:topN]
})}
get_targets <- function(TF){
    lapply(TF, )
}


rss <- read.csv(paste0(input, '/', label, '.auc_rss.celltype_family.csv'), check.names = FALSE, row.names = 1)
rownames(rss) <- vapply(rownames(rss), FUN = function(x){ gsub('\\(\\+\\)','',x)}, FUN.VALUE = character(1))
regulon <- read.csv(paste0(input, '/', label, '.regulons_df.csv'), check.names = FALSE)
regulon$TF <- vapply(regulon$TF, FUN = function(x){ gsub('\\(\\+\\)','',x)}, FUN.VALUE = character(1))
regulon <- regulon[regulon$value > 1, ]

number <- c(10,25,50)
for (i in number){
    rss_top <- get_topN_RSS(rss, i)
    rss_top <- reshape2::melt(rss_top)
    rss_top$Var1 <- NULL
    colnames(rss_top) <- c('cluster', 'TF')
    res <- merge(rss_top, regulon, by = "TF", all.x = TRUE)
    colnames(res) <- c('TF', 'cluster', 'gene', 'value')
    res <- unique(res[,c('cluster', 'gene')])
    colnames(rss_top) <- c('cluster', 'gene')
    write.table(rss_top, paste0(label, '.top',i,'RSS.txt'), quote = F, sep = '\t', row.names = F, col.names = T)
    write.table(res, paste0(label, '.top',i,'RSS_targets.weight1.txt'), quote = F, sep = '\t', row.names = F, col.names = T)
}
