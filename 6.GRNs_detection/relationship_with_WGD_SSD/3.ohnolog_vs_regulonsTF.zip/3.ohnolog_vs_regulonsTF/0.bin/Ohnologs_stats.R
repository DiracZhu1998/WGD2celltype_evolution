library(Seurat)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(cowplot)
library(igraph)
require(VennDiagram)


parser = argparse::ArgumentParser(description="Test ohnolog importance on cell marker genes")
parser$add_argument('-I','--count', help='Input count matrix')
parser$add_argument('-R','--rss', help='Input rss matrix')
parser$add_argument('-TF','--tf', help='Input TF file')
parser$add_argument('-P','--ohnolog', help='input Seurat ohnolog file retrieved from Ohnolog v2')
parser$add_argument('-S','--species', help='input species name')
parser$add_argument('-O','--out', help='input output path')
args = parser$parse_args()

species <- args$species
if (!dir.exists(args$out)) {
  dir.create(args$out, recursive = TRUE)
  print(paste("Path:", args$out, " created."))
}

rss <- read.csv(args$rss, check.names = FALSE, row.names = 1)
rownames(rss) <- vapply(rownames(rss), FUN = function(x){ gsub('\\(\\+\\)','',x)}, FUN.VALUE = character(1))
colnames(rss) <- as.character(colnames(rss))

count <- read.csv(args$count, header = T)
TF <- read.table(args$tf)$V1

########## Ohnologs #############
# read ohnolog file
ohnologs <- read.delim(args$ohnolog, header = T)

# get family level ohnologs
g <- graph_from_data_frame(ohnologs[,c(1,2)], directed = FALSE)
components <- clusters(g)$membership
ohnolog_pairs <- split(names(components), components)

ohnolog_number_in_ourdata <- sum(unique(c(ohnologs$Ohno1, ohnologs$Ohno2)) %in%  rownames(count))
ohnolog_ratio_in_ourdata <- round(ohnolog_number_in_ourdata/length(rownames(count)),2)
non_ohnolog_number_in_ourdata <- sum(!rownames(count) %in% unique(c(ohnologs$Ohno1, ohnologs$Ohno2)))

# get stats of ohnologs of this dataset ###
ohnologs_in_our_dataset <- ohnologs[ohnologs$Ohno1 %in% rownames(count) & ohnologs$Ohno2 %in% rownames(count), ]
g <- graph_from_data_frame(ohnologs_in_our_dataset[,c(1,2)], directed = FALSE)
components <- clusters(g)$membership
ohnolog_pairs_in_our_dataset <- split(names(components), components)

###### calculate top N RSS regulons #########
get_topN_RSS <- function(data, topN){
    apply(data, MARGIN = 2, FUN = function(x){ rownames(rss)[order(x, decreasing = T)][1:topN]
})}

stats_for_chi2 <- data.frame(gene = rownames(count), top25 = NA, top50 = NA, top100 = NA, ohnolog = NA, TF = NA)
stats_for_chi2$ohnolog <- stats_for_chi2$gene %in% unique(c(ohnologs$Ohno1, ohnologs$Ohno2))
stats_for_chi2$TF <- stats_for_chi2$gene %in% TF

for (number in c(25,50,100)){
    rss_top <- get_topN_RSS(rss, number)
    rss_top <- reshape2::melt(rss_top)[,c(2:3)]
    colnames(rss_top) <- c("cluster", "gene")

    stats <- rss_top %>% as_tibble() %>% group_by(cluster) %>%
        summarise(total = length(cluster), 
                  n_ohnologs = sum(gene %in% unique(c(ohnologs$Ohno1, ohnologs$Ohno2))), # calculate number of ohnologs
                  n_ohnolog_pairs = length(unique(vapply(gene[gene %in% unique(c(ohnologs$Ohno1, ohnologs$Ohno2))],
                                                         FUN =  function(y) {which(sapply(ohnolog_pairs, function(x) y %in% x))}, FUN.VALUE = double(1)))),
                  "ohnologs%" = n_ohnologs/total,
                  "families_divided_by_ohnologs%" = n_ohnolog_pairs/n_ohnologs
                  ) %>% ungroup()

    p1 <- stats %>% as.data.frame() %>% ggplot(aes(`ohnologs%`)) + geom_density(fill="#69b3a2", color="#e9ecef", alpha=0.6) +
        geom_vline(aes(xintercept=mean(`ohnologs%`)), color="blue", linetype="dashed", linewidth=1) + 
        geom_vline(aes(xintercept=ohnolog_ratio_in_ourdata), color="red", linetype="dashed", linewidth=1) + xlim(0,1)
    ggsave(paste0(args$out, '/', species,".ohnolog_ratio_inTop", number ,"RSS.pdf"), p1, width = 6, height = 2)

    p2 <- stats %>% as.data.frame() %>% ggplot(aes(`families_divided_by_ohnologs%`)) +
        geom_density(fill="#69b3a2", color="#e9ecef", alpha=0.6) + 
        geom_vline(aes(xintercept=mean(`families_divided_by_ohnologs%`)), color="blue", linetype="dashed", linewidth=1) +
        geom_vline(aes(xintercept=length(ohnolog_pairs_in_our_dataset)/length(unlist(ohnolog_pairs_in_our_dataset))),
                   color="red", linetype="dashed", linewidth=1) + xlim(0,1)
    ggsave(paste0(args$out, '/', species,".ohnolog_families_divided_ohnologs_inTop", number, "RSS.pdf"), p2, width = 6, height = 2)
    
    tmp <- paste0("Top", number)
    stats_for_chi2[,tmp] <- stats_for_chi2$gene %in% rss_top$gene
    
    # venn plot show top RSS regulons and ohnologs
    venn.plot <- venn.diagram(
                              x = list(set1 = stats_for_chi2[stats_for_chi2[,tmp], "gene"], 
                                       set2 = stats_for_chi2[stats_for_chi2$ohnolog, "gene"]
                                       ),
                              category.names = c(tmp, "ohnologs"),
                              filename = paste0(args$out, '/', species,".top",number,"RSS_ohnologs.Venn.png"),
                              col=c("#440154ff", '#21908dff'),
                              fill = c(alpha("#440154ff",0.3), alpha('#21908dff',0.3)),
                              output = TRUE
                              )

    # chi squared test of ohnologs and top RSS regulon TFs
    chi <- data.frame(matrix(data = c(sum(stats_for_chi2[,tmp] & stats_for_chi2$ohnolog),
                                      sum(stats_for_chi2[,tmp] & !stats_for_chi2$ohnolog),
                                      sum(!stats_for_chi2[,tmp] & stats_for_chi2$ohnolog),
                                      sum(!stats_for_chi2[,tmp] & !stats_for_chi2$ohnolog) 
                                      ), ncol = 2, byrow = T))

    rownames(chi) <- c(tmp, "others")
    colnames(chi) <- c("ohnologs", "non-ohnologs")
    write.table(x = chi, file = paste0(args$out, '/', species, ".ohnolog_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = T, row.names = T)
    write.table(x = capture.output(print(chisq.test(chi, correct = F)))[5], file = paste0(args$out, '/', species, ".ohnolog_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = F, row.names = F, append = T)
    write(paste0("OR = ",(chi[1,1]*chi[2,2])/(chi[1,2]*chi[2,1])), file = paste0(args$out, '/', species, ".ohnolog_", tmp, "RSS.chi2.txt"), sep = "\t", append = T)
    

    # chi squared test of ohnolog_TF and top RSS regulon TFs
    chi <- data.frame(matrix(data = c(sum(stats_for_chi2$TF & (stats_for_chi2[,tmp] & stats_for_chi2$ohnolog)),
                                      sum(stats_for_chi2$TF & (stats_for_chi2[,tmp] & !stats_for_chi2$ohnolog)),
                                      sum(stats_for_chi2$TF & (!stats_for_chi2[,tmp] & stats_for_chi2$ohnolog)),
                                      sum(stats_for_chi2$TF & (!stats_for_chi2[,tmp] & !stats_for_chi2$ohnolog)) 
                                      ), ncol = 2, byrow = T))

    rownames(chi) <- c(tmp, "others")
    colnames(chi) <- c("ohnologs_TF", "non-ohnologs_TF")
    write.table(x = chi, file = paste0(args$out, '/', species, ".ohnologTF_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = T, row.names = T)
    write.table(x = capture.output(print(chisq.test(chi, correct = F)))[5], file = paste0(args$out, '/', species, ".ohnologTF_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = F, row.names = F, append = T)
    write(paste0("OR = ",(chi[1,1]*chi[2,2])/(chi[1,2]*chi[2,1])), file = paste0(args$out, '/', species, ".ohnologTF_", tmp, "RSS.chi2.txt"), sep = "\t", append = T)
}

write.table(stats_for_chi2, file = paste0(args$out, '/', species, ".ohnologs_topRSS_TFs.stats.txt"), sep = "\t", quote = F, col.names = T, row.names = T)



# test TF vs Ohnologs
chi <- data.frame(matrix(data = c(sum(stats_for_chi2$TF &  stats_for_chi2$ohnolog),
                                  sum(stats_for_chi2$TF &  !stats_for_chi2$ohnolog),
                                  sum(!stats_for_chi2$TF & stats_for_chi2$ohnolog),
                                  sum(!stats_for_chi2$TF & !stats_for_chi2$ohnolog)
                                  ), ncol = 2, byrow = T))
rownames(chi) <- c("TF", "non-TF")
colnames(chi) <- c("ohnologs", "non-ohnologs")
write.table(x = chi, file = paste0(args$out, '/', species, ".ohnolog_TF.chi2.txt"), sep = "\t", quote = F, col.names = T, row.names = T)
write.table(x = capture.output(print(chisq.test(chi, correct = F)))[5], file = paste0(args$out, '/', species, ".ohnolog_TF.chi2.txt"), sep = "\t", quote = F, col.names = F, row.names = F, append = T)
write(paste0("OR = ",(chi[1,1]*chi[2,2])/(chi[1,2]*chi[2,1])), file = paste0(args$out, '/', species, ".ohnolog_TF.chi2.txt"), sep = "\t", append = T)


