library(Seurat)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(cowplot)
library(igraph)
require(VennDiagram)


parser = argparse::ArgumentParser(description="Test paralog importance on cell marker genes")
parser$add_argument('-I','--count', help='Input count matrix')
parser$add_argument('-R','--rss', help='Input rss matrix')
parser$add_argument('-TF','--tf', help='Input TF file')
parser$add_argument('-P1','--paralog', help='input Seurat paralog file retrieved from Ensembl')
parser$add_argument('-P2','--ohnolog', help='input Seurat ohnolog file retrieved from Ohnolog v2')
parser$add_argument('-S','--species', help='input species name')
parser$add_argument('-O','--out', help='input output path')
args = parser$parse_args()

species <- args$species
if (!dir.exists(args$out)) {
  dir.create(args$out, recursive = TRUE)
  print(paste("Path:", args$out, " created."))
}

rss <- read.csv(args$rss, check.names = FALSE, row.names = 1)
rownames(rss) <- vapply(rownames(rss), FUN = function(x){ gsub('\\(\\+\\)','',x)}, FUN.VALUE = character(1))
colnames(rss) <- as.character(colnames(rss))

count <- read.csv(args$count, header = T)
TF <- read.table(args$tf)$V1

########## SSD Paralogs #############
# read paralog file
paralogs <- read.delim(args$paralog, header = T, sep = ",")
# remove species name for convenience
colnames(paralogs) <- vapply(colnames(paralogs), FUN = function(x){
  gsub(paste0("\\.?",species,"\\.?"), "", x) 
}, FUN.VALUE = character(1))

paralogs <- paralogs[which(paralogs$Gene.stable.ID != "" & paralogs$paralogue.gene.stable.ID != ""), ]
paralogs[paralogs$Gene.name == "", "Gene.name"] <- paralogs[paralogs$Gene.name == "", "Gene.stable.ID"]
paralogs[paralogs$paralogue.associated.gene.name == "", "paralogue.associated.gene.name"] <-
      paralogs[paralogs$paralogue.associated.gene.name == "", "paralogue.gene.stable.ID"]

# read ohnolog file
  ohnologs <- read.delim(args$ohnolog, header = T)
# filter and to get SSD paralogs 
paralogs <- paralogs[!paralogs$Gene.stable.ID %in% unique(c(ohnologs$Ohno1, ohnologs$Ohno2)),]
paralogs <- paralogs[!paralogs$paralogue.gene.stable.ID %in% unique(c(ohnologs$Ohno1, ohnologs$Ohno2)),]

# get family level paralogs (SSD paralogs actually, for convience, paralogs)
g <- graph_from_data_frame(paralogs[,c(1,3)], directed = FALSE)
components <- clusters(g)$membership
paralog_pairs <- split(names(components), components)

paralog_number_in_ourdata <- sum(unique(c(paralogs$Gene.stable.ID, paralogs$paralogue.gene.stable.ID)) %in%  rownames(count))
paralog_ratio_in_ourdata <- round(paralog_number_in_ourdata/length(rownames(count)),2)
non_paralog_number_in_ourdata <- sum(!rownames(count) %in% unique(c(paralogs$Gene.stable.ID, paralogs$paralogue.gene.stable.ID)))
# get stats of paralogs of this dataset ###
paralogs_in_our_dataset <- paralogs[paralogs$Gene.stable.ID %in% rownames(count) & paralogs$paralogue.gene.stable.ID %in% rownames(count), ]
g <- graph_from_data_frame(paralogs_in_our_dataset[,c(1,3)], directed = FALSE)
components <- clusters(g)$membership
paralog_pairs_in_our_dataset <- split(names(components), components)

###### calculate top N RSS regulons #########
get_topN_RSS <- function(data, topN){
    apply(data, MARGIN = 2, FUN = function(x){ rownames(rss)[order(x, decreasing = T)][1:topN]
})}

stats_for_chi2 <- data.frame(gene = rownames(count), top25 = NA, top50 = NA, top100 = NA, paralog = NA, TF = NA)
stats_for_chi2$paralog <- stats_for_chi2$gene %in% unique(c(paralogs$Gene.stable.ID, paralogs$paralogue.gene.stable.ID))
stats_for_chi2$TF <- stats_for_chi2$gene %in% TF

for (number in c(25,50,100)){
    rss_top <- get_topN_RSS(rss, number)
    rss_top <- reshape2::melt(rss_top)[,c(2:3)]
    colnames(rss_top) <- c("cluster", "gene")

    stats <- rss_top %>% as_tibble() %>% group_by(cluster) %>%
        summarise(total = length(cluster), 
                  n_paralogs = sum(gene %in% unique(c(paralogs$Gene.stable.ID, paralogs$paralogue.gene.stable.ID))), # calculate number of paralogs
                  n_paralog_pairs = length(unique(vapply(gene[gene %in% unique(c(paralogs$Gene.stable.ID, paralogs$paralogue.gene.stable.ID))],
                                                         FUN =  function(y) {which(sapply(paralog_pairs, function(x) y %in% x))}, FUN.VALUE = double(1)))),
                  "paralogs%" = n_paralogs/total,
                  "families_divided_by_paralogs%" = n_paralog_pairs/n_paralogs
                  ) %>% ungroup()

    p1 <- stats %>% as.data.frame() %>% ggplot(aes(`paralogs%`)) + geom_density(fill="#69b3a2", color="#e9ecef", alpha=0.6) +
        geom_vline(aes(xintercept=mean(`paralogs%`)), color="blue", linetype="dashed", linewidth=1) + 
        geom_vline(aes(xintercept=paralog_ratio_in_ourdata), color="red", linetype="dashed", linewidth=1) + xlim(0,1)
    ggsave(paste0(args$out, '/', species,".paralog_ratio_inTop", number ,"RSS.pdf"), p1, width = 6, height = 2)

    p2 <- stats %>% as.data.frame() %>% ggplot(aes(`families_divided_by_paralogs%`)) +
        geom_density(fill="#69b3a2", color="#e9ecef", alpha=0.6) + 
        geom_vline(aes(xintercept=mean(`families_divided_by_paralogs%`)), color="blue", linetype="dashed", linewidth=1) +
        geom_vline(aes(xintercept=length(paralog_pairs_in_our_dataset)/length(unlist(paralog_pairs_in_our_dataset))),
                   color="red", linetype="dashed", linewidth=1) + xlim(0,1)
    ggsave(paste0(args$out, '/', species,".paralog_families_divided_paralogs_inTop", number, "RSS.pdf"), p2, width = 6, height = 2)
    
    tmp <- paste0("Top", number)
    stats_for_chi2[,tmp] <- stats_for_chi2$gene %in% rss_top$gene
    
    # venn plot show top RSS regulons and paralogs
    venn.plot <- venn.diagram(
                              x = list(set1 = stats_for_chi2[stats_for_chi2[,tmp], "gene"], 
                                       set2 = stats_for_chi2[stats_for_chi2$paralog, "gene"]
                                       ),
                              category.names = c(tmp, "paralogs"),
                              filename = paste0(args$out, '/', species,".top",number,"RSS_paralogs.Venn.png"),
                              col=c("#440154ff", '#21908dff'),
                              fill = c(alpha("#440154ff",0.3), alpha('#21908dff',0.3)),
                              output = TRUE
                              )

    # chi squared test of paralogs and top RSS regulon TFs
    chi <- data.frame(matrix(data = c(sum(stats_for_chi2[,tmp] & stats_for_chi2$paralog),
                                      sum(stats_for_chi2[,tmp] & !stats_for_chi2$paralog),
                                      sum(!stats_for_chi2[,tmp] & stats_for_chi2$paralog),
                                      sum(!stats_for_chi2[,tmp] & !stats_for_chi2$paralog) 
                                      ), ncol = 2, byrow = T))

    rownames(chi) <- c(tmp, "others")
    colnames(chi) <- c("SSDparalogs", "others")
    write.table(x = chi, file = paste0(args$out, '/', species, ".SSDparalog_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = T, row.names = T)
    write.table(x = capture.output(print(chisq.test(chi, correct = F)))[5], file = paste0(args$out, '/', species, ".SSDparalog_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = F, row.names = F, append = T)
    write(paste0("OR = ",(chi[1,1]*chi[2,2])/(chi[1,2]*chi[2,1])), file = paste0(args$out, '/', species, ".SSDparalog_", tmp, "RSS.chi2.txt"), sep = "\t", append = T)
    

    # chi squared test of paralog_TF and top RSS regulon TFs
    chi <- data.frame(matrix(data = c(sum(stats_for_chi2$TF & (stats_for_chi2[,tmp] & stats_for_chi2$paralog)),
                                      sum(stats_for_chi2$TF & (stats_for_chi2[,tmp] & !stats_for_chi2$paralog)),
                                      sum(stats_for_chi2$TF & (!stats_for_chi2[,tmp] & stats_for_chi2$paralog)),
                                      sum(stats_for_chi2$TF & (!stats_for_chi2[,tmp] & !stats_for_chi2$paralog)) 
                                      ), ncol = 2, byrow = T))

    rownames(chi) <- c(tmp, "others")
    colnames(chi) <- c("SSDparalogs_TF", "other_TFs")
    write.table(x = chi, file = paste0(args$out, '/', species, ".SSDparalogTF_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = T, row.names = T)
    write.table(x = capture.output(print(chisq.test(chi, correct = F)))[5], file = paste0(args$out, '/', species, ".SSDparalogTF_", tmp, "RSS.chi2.txt"), sep = "\t", quote = F, col.names = F, row.names = F, append = T)
    write(paste0("OR = ",(chi[1,1]*chi[2,2])/(chi[1,2]*chi[2,1])), file = paste0(args$out, '/', species, ".SSDparalogTF_", tmp, "RSS.chi2.txt"), sep = "\t", append = T)
}

write.table(stats_for_chi2, file = paste0(args$out, '/', species, ".SSDparalogs_topRSS_TFs.stats.txt"), sep = "\t", quote = F, col.names = T, row.names = T)



# test TF vs Paralogs
chi <- data.frame(matrix(data = c(sum(stats_for_chi2$TF &  stats_for_chi2$paralog),
                                  sum(stats_for_chi2$TF &  !stats_for_chi2$paralog),
                                  sum(!stats_for_chi2$TF & stats_for_chi2$paralog),
                                  sum(!stats_for_chi2$TF & !stats_for_chi2$paralog)
                                  ), ncol = 2, byrow = T))
rownames(chi) <- c("TF", "non-TF")
colnames(chi) <- c("SSDparalogs", "others")
write.table(x = chi, file = paste0(args$out, '/', species, ".SSDparalog_TF.chi2.txt"), sep = "\t", quote = F, col.names = T, row.names = T)
write.table(x = capture.output(print(chisq.test(chi, correct = F)))[5], file = paste0(args$out, '/', species, ".SSDparalog_TF.chi2.txt"), sep = "\t", quote = F, col.names = F, row.names = F, append = T)
write(paste0("OR = ",(chi[1,1]*chi[2,2])/(chi[1,2]*chi[2,1])), file = paste0(args$out, '/', species, ".SSDparalog_TF.chi2.txt"), sep = "\t", append = T)


