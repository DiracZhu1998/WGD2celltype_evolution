import sys, re, os
import multiprocessing

if ("--help" in sys.argv) or ("-h" in sys.argv):
    sys.stderr.write("#this programme is used for calculating Ka/Ks in duplicated gene families \nusage: python3 calculate_Ka_Ks_pipe.py  <cds file>  <family files> <out pre-name>\n")
    exit()

try:
    cds=sys.argv[1]
    family=sys.argv[2]
    name = sys.argv[3]
except:
    exit("usage: python3 calculate_Ka_Ks_pipe.py  <cds file>  <family files> <out prefix name>")

tmpdir = name + '.tmp'
if not os.path.exists(tmpdir):
    os.makedirs(tmpdir)

IDs = []
task = 0
for line in open(family):
    task += 1
    ID = f'task{task}'
    IDs.append(ID)

    with open(f'{tmpdir}/{ID}.id', 'w') as write_:
        write_.write('\n'.join(line.strip().split()))


def run_get_trans(ID):
    os.system(f'python3 /home/zoo/ball6395/00bin/get_seq_by_ID.py {tmpdir}/{ID}.id {cds} > {tmpdir}/{ID}.cds')
    os.system(f'python3 /mnt/data01/yuanzhen/01.Vertebrate_cell_evo/10.dNdS/0.bin/translator2.py {tmpdir}/{ID}.cds > {tmpdir}/{ID}.pep')

with multiprocessing.Pool( processes = 10 ) as pool:
    pool.map(run_get_trans, IDs)


def run_mafft(ID):
    os.system(f'mafft --localpair --maxiterate 1000 --anysymbol --quiet {tmpdir}/{ID}.pep > {tmpdir}/{ID}.pep.aln')

with multiprocessing.Pool( processes = 10 ) as pool:
    pool.map(run_mafft, IDs)

for ID in IDs:
    os.system(f'perl pal2nal.pl {tmpdir}/{ID}.pep.aln {tmpdir}/{ID}.cds -output fasta -nogap  > {tmpdir}/{ID}.coding.aln') # nogap?
    os.system(f'perl parseFastaIntoAXT.pl {tmpdir}/{ID}.coding.aln ')  # will output to  {tmpdir}/{ID}.coding.aln.axt


os.system(f'find {tmpdir}/ -name \"*.axt\" | xargs cat > {tmpdir}/all_axt')
os.system(f'./KaKs_Calculator -i {tmpdir}/all_axt -m GMYN -o {tmpdir}/{name}.KKC.format > {tmpdir}/{name}.KKC.logfile')





with open(f'{tmpdir}/{name}.KKC.format', 'r') as IN, open(f'{name}.kaks', 'w') as OUT:
    for line in IN:
        line = line.strip().split('\t')
        OUT.write(f"{line[0]}\t{line[2]}\t{line[3]}\t{line[4]}\t{line[5]}\n")

# Run sed command
#sed_command = f"sed -i '1i\\Gene pairs\tMethod\tKa\tKs\tKa/Ks\tP-Value (Fisher)\tLength\tS-Sites\tN-Sites\tFold-Sites (0:2:4)\tSubstitutions\tS-Substitutions\tN-Substitutions\tFold-S-Substitutions (0:2:4)\tFold-N-Substitutions (0:2:4)\tDivergence-Time\tSubstitution-Rate-Ratio (rTC:rAG:rTA:rCG:rTG:rCA/rCA)\tGC(1:2:3)\tML-Score\tAICc\tAkaike-Weight\tModel\n' {tmpdir}/{name}.KKC.format"
#os.system(sed_command)



