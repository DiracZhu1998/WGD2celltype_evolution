
ID12 = {}
ID21 = {}
for line in open('output_file_1'):
    line = line.strip().split('\t')
    if float(line[-2]) < 0.00001:
        try:
            ID12[line[0]].append(line[1])
        except:
            ID12[line[0]] = [line[1]]

for line in open('output_file_2'):
    line = line.strip().split('\t')
    if float(line[-2]) < 0.00001:
        try:
            ID21[line[0]].append(line[1])
        except:
            ID21[line[0]] = [line[1]]

for key, values in ID12.items():
    for v in values:
        try:
            if key in ID21[v]:
                print(f'{key}\t{v}')
        except:
            pass
